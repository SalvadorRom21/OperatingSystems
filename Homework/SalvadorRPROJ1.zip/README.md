SALVADOR ROMERO
PROJECT 1
OPERATING SYSTEM: 4.17.0-kali1-amd64

make sure you are running all the commands in the directory where all the files are located

To run pre.c alone:

1:uncomment the printf() functions to get the output to display on the command line
2:build "gcc -o pre pre.c" on the Terminal
3:run ./pre
4: Press ENTER once and then start Typing initials and population of STATES hitting enter after every line
	TX 27 (enter)
	NY 19 (enter)
	MI 9  (enter)
5: when you want to stop press ctrl-D twice 


To run sort.c alone:
1: uncoments the printf() functions to get teh output to display on the command line
2: build "gcc -o sort sort.c" on Terminal
3: run ./sort
4: Press ENTER once and then start typing the Initials hit enter after every entry
	TX (ENTER)
	AL (ENTER)
	CN (ENTER)
5: when you want to stop press ctrl-D



To run pre.c 
1: make sure you have the executables of pre.c and sort as pre and sort
2:comment out the printf() functions that were previously commented out after running both pre.c and sort.c 
3: build "gcc -Wall -Werror -o pipe pipe.c"
4: run ./pipe 
5: Press ENTER once and then start Typing initials and population of STATES hitting enter after every line
	TX 27 (enter)
	NY 19 (enter)
	MI 9  (enter)
6: when you want to stop press ctrl-D twice 

To run UNIXCMD.c

1: build "gcc -o UNIXCMD UNIXCMD.c"
2 run ./UNIXCMD (arguments)
  exmaple ./UNIXCMD ls -t -l

	

 